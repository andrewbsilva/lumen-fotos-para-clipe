# LUMEN FOTOS PARA CLIPE — base funcional de integração ao Google Drive

Esta é uma **base de desenvolvimento**, não um aplicativo publicado. Os 30 cadastros iniciais e os 6 representantes estão incluídos. O formulário do aluno recebe uma imagem, reduz a imagem para JPEG e salva no Google Drive **após a integração ser autorizada**. A criação de pastas por ano/representante/escola ocorre no primeiro upload.

## Para executar localmente

1. Instale Node.js 20 ou superior e execute `npm install` nesta pasta.
2. Copie `.env.example` para `.env`. Defina uma senha administrativa forte e `SESSION_SECRET` aleatório.
3. No Google Cloud Console, crie um projeto, habilite **Google Drive API**, configure a tela de consentimento OAuth e crie credenciais **OAuth 2.0 Web application**. Cadastre `http://localhost:3000/oauth/callback` como URI de redirecionamento (ou a URL HTTPS definitiva na implantação). Em modo de testes, adicione sua conta Google como usuário de teste.
4. Preencha `GOOGLE_CLIENT_ID` e `GOOGLE_CLIENT_SECRET` no `.env`.
5. No seu Drive pessoal, crie uma pasta privada `LUMEN FOTOS PARA CLIPE`, copie o ID da pasta na URL e preencha `DRIVE_ROOT_FOLDER_ID`.
6. Execute `npm start` e acesse `http://localhost:3000/admin`. Entre com as credenciais do `.env` e clique em **Conectar meu Google Drive**. Autorize a conta Google escolhida.
7. Copie um link de escola no painel e teste o envio de uma foto. Confira a pasta criada no Drive.

## Atenção antes de publicar para alunos

- Esta base possui **somente um login administrativo**. O login individual dos 6 representantes, com controle de permissões por escola, ainda precisa ser desenvolvido.
- O painel permite listar envios, mas **ainda não inclui download ZIP** e aprovação de imagens.
- O checkbox de autorização é **apenas um protótipo**; para menores, implemente um fluxo verificável de autorização do responsável legal antes de uso público.
- É preciso implementar proteção anti-spam mais forte (CAPTCHA), políticas de privacidade, retenção/exclusão, backup, logs, proteção CSRF, sessões persistentes, gestão de segredos e hospedagem HTTPS segura. `express-session` com armazenamento padrão em memória não é adequado à produção.
- O escopo OAuth `drive.file` limita acesso aos arquivos criados/abertos pelo aplicativo. Em algumas configurações, uma pasta criada manualmente no Drive não estará acessível por esse escopo; nesse caso, use Google Picker para conceder acesso à pasta ou ajuste a estratégia de autorização com revisão de escopos antes da produção. **Não amplie para acesso total ao Drive sem necessidade.**
- Um aplicativo OAuth externo em modo de testes pode ter tokens de atualização com validade limitada. Planeje o processo de publicação/verificação OAuth.
- Não compartilhe `.env`, tokens OAuth ou banco SQLite; adicione-os ao `.gitignore`.
- Os links dos alunos só funcionarão fora da sua rede depois de hospedar o servidor em um domínio público HTTPS. O ChatGPT não publica esse projeto nem autoriza sua conta Google automaticamente.
- O Drive pessoal tem limite de armazenamento e quotas da API; monitore ambos para 2.000+ fotos.

## Fluxo de teste

Aluno abre `/enviar/TOKEN` → preenche nome/turma → seleciona imagem → confirma autorização → backend valida e converte → cria pastas → envia arquivo à API Google Drive → grava registro no SQLite → confirma envio.
